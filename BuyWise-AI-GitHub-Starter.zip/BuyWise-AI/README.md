# BuyWise AI

A Python Flask starter website for an AI-powered shopping assistant.

## Features in this starter

- Sage, olive, forest-green and cream responsive interface
- Shopping categories and retailer shortcuts
- AED budget slider
- Five shopping priorities
- Feature filters and brand filter
- Product cards with BUY / COMPARE / SKIP demo verdicts
- Multi-retailer price comparison from a local JSON catalogue
- Budget-stretch explanation
- Chat panel with optional OpenAI API integration
- Exact product URL fields for direct retailer product pages

## Important: demo data

`products.json` contains illustrative sample products and prices. It is not connected to Amazon, noon, SHEIN, Carrefour or other retailer inventories. Do not present sample prices as live prices.

For a direct-to-product-page link, edit a product's `retailers` array in `products.json` and put the verified product detail URL in `product_url`. Do not put a retailer homepage or search-results URL there. If no exact product URL is available, the website intentionally shows "Product link not added yet".

## Run locally

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment:

   Windows:
   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   ```

   macOS / Linux:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the website:

   ```bash
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

## Optional OpenAI chatbot

The chatbot works in demo mode without an API key. To connect an AI model, set the `OPENAI_API_KEY` environment variable on your computer or hosting provider. Never put the key in `script.js`, HTML, GitHub, or any public file.

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="your-key-here"
python app.py
```

macOS / Linux:
```bash
export OPENAI_API_KEY="your-key-here"
python app.py
```

You can set `OPENAI_MODEL` to a model available to your API account. The default in this starter is `gpt-4.1-mini`.

## Push to GitHub

1. Create a new empty repository on GitHub, e.g. `buywise-ai`.
2. In the project folder, run:

   ```bash
   git init
   git add .
   git commit -m "Initial BuyWise AI website"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/buywise-ai.git
   git push -u origin main
   ```

3. Replace `YOUR-USERNAME` with your GitHub username.

## Deploy with Render

1. Push the project to GitHub.
2. Sign in at https://render.com and create a new **Web Service**.
3. Connect the BuyWise AI GitHub repository.
4. Use these settings:
   - Runtime: Python
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
5. Add `OPENAI_API_KEY` as a private environment variable if using the AI chat.
6. Deploy. Render will provide a public URL.

## Before a real public launch

- Use approved retailer APIs, affiliate feeds, or permitted product-data providers.
- Follow each retailer's terms, rate limits, and attribution requirements.
- Verify product identity (model, size, colour, pack quantity) before comparing prices.
- Include shipping, delivery, coupons, VAT and stock status where possible.
- Store secrets in environment variables, never in GitHub.
- Add authentication, privacy policy, security protections, monitoring and tests.
- Treat the recommendation score as a transparent ranking aid, not a claim of objectively measured product quality.
