import json
import os
from pathlib import Path

from flask import Flask, jsonify, render_template, request

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__)

with open(BASE_DIR / "products.json", encoding="utf-8") as f:
    PRODUCTS = json.load(f)


def rank_product(product, budget, priority, features):
    """Transparent demo scoring. Replace with richer product-specific scoring later."""
    price = product["price"]
    score = float(product.get("base_score", 75))

    if priority == "cheapest":
        score += 18 if price <= budget else -15
        score -= min(price / max(budget, 1), 3) * 3
    elif priority == "value":
        score += 12 if price <= budget else -10
        score += product.get("value_score", 0)
    elif priority == "longevity":
        score += product.get("durability_score", 0) * 0.20
    elif priority == "premium":
        score += product.get("quality_score", 0) * 0.20
    else:  # balanced
        score += product.get("value_score", 0) * 0.10
        score += product.get("durability_score", 0) * 0.10

    # Small bonus when a product's feature tags match the user's selected priorities.
    tags = {tag.lower() for tag in product.get("features", [])}
    score += sum(3 for feature in features if feature.lower() in tags)
    return round(max(0, min(score, 99)))


def verdict_for(product, budget, score):
    if score >= 82 and product["price"] <= budget:
        return "BUY"
    if product["price"] > budget:
        return "COMPARE"
    if score >= 68:
        return "COMPARE"
    return "SKIP"


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/products")
def get_products():
    query = request.args.get("q", "").strip().lower()
    category = request.args.get("category", "All")
    brand = request.args.get("brand", "").strip().lower()
    budget = request.args.get("budget", default=1500, type=float)
    priority = request.args.get("priority", "value")
    features = [x.strip() for x in request.args.get("features", "").split(",") if x.strip()]

    results = []
    for original in PRODUCTS:
        product = dict(original)
        if category != "All" and product["category"] != category:
            continue
        searchable = f'{product["name"]} {product["brand"]} {product["category"]}'.lower()
        if query and query not in searchable:
            continue
        if brand and brand not in product["brand"].lower():
            continue

        product["match_score"] = rank_product(product, budget, priority, features)
        product["verdict"] = verdict_for(product, budget, product["match_score"])
        product["over_budget_by"] = max(0, round(product["price"] - budget, 2))
        results.append(product)

    results.sort(key=lambda p: (p["match_score"], -p["price"]), reverse=True)
    return jsonify({
        "products": results,
        "count": len(results),
        "note": "Starter catalogue data. Prices and retailer links must be verified before production."
    })


@app.post("/api/chat")
def chat():
    body = request.get_json(silent=True) or {}
    message = body.get("message", "").strip()
    if not message:
        return jsonify({"reply": "Tell me what you're shopping for and I'll help you narrow it down."}), 400

    # Optional real AI integration. Add OPENAI_API_KEY to your hosting environment.
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            response = client.responses.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
                instructions=(
                    "You are BuyWise AI, a neutral shopping adviser. Be concise and practical. "
                    "Never invent product prices, stock, specifications, reviews, or retailer links. "
                    "Explain trade-offs and respect the user's budget. If product data is missing, say so."
                ),
                input=message
            )
            return jsonify({"reply": response.output_text})
        except Exception:
            app.logger.exception("AI request failed")

    return jsonify({
        "reply": (
            "I'm your BuyWise shopping companion! 🌿 I can help you think through your options. "
            "Tell me your product, budget, intended use and top priorities. "
            "This starter chatbot is in demo mode until you add an OPENAI_API_KEY. "
            "For product recommendations, use the finder so I can show the catalogue entries available."
        )
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)), debug=True)
