let selectedPriority = "value";

const $ = (id) => document.getElementById(id);
const money = (amount) => Number(amount).toLocaleString("en-US");

$("budget").addEventListener("input", () => {
  $("budgetLabel").textContent = money($("budget").value);
});

document.querySelectorAll(".priority").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".priority").forEach((item) => item.classList.remove("selected"));
    button.classList.add("selected");
    selectedPriority = button.dataset.priority;
  });
});

document.querySelectorAll(".category").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".category").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    $("category").value = button.dataset.category;
    $("finder").scrollIntoView({ behavior: "smooth" });
  });
});

async function findProducts() {
  const features = [...document.querySelectorAll('.chips input:checked')].map(x => x.value);
  const params = new URLSearchParams({
    q: $("query").value.trim(),
    category: $("category").value,
    budget: $("budget").value,
    priority: selectedPriority,
    brand: $("brand").value.trim(),
    features: features.join(",")
  });

  $("productGrid").innerHTML = '<div class="loading">Finding your matches…</div>';
  try {
    const response = await fetch(`/api/products?${params}`);
    if (!response.ok) throw new Error("Could not load products");
    const data = await response.json();
    $("resultCaption").textContent =
      `${data.count} catalogue match(es) · ${selectedPriority.replace("longevity", "long-term investment")} · AED ${money($("budget").value)} budget`;
    renderProducts(data.products, Number($("budget").value));
  } catch (error) {
    $("productGrid").innerHTML = '<div class="empty">Could not load the catalogue. Check that the Flask server is running.</div>';
  }
}

function renderProducts(products, budget) {
  if (!products.length) {
    $("productGrid").innerHTML = '<div class="empty">No exact matches found. Try another category, brand or search term.</div>';
    return;
  }

  $("productGrid").innerHTML = products.map(product => {
    const verdictClass = product.verdict.toLowerCase();
    const retailerRows = product.retailers.map(retailer => `
      <div class="store-price">
        <span>${escapeHtml(retailer.name)}</span>
        <b>AED ${money(retailer.price)}</b>
      </div>`).join("");
    const hasProductLink = product.retailers.some(r => r.product_url);
    const firstProductLink = product.retailers.find(r => r.product_url)?.product_url;
    const linkMarkup = hasProductLink
      ? `<a class="product-link" href="${escapeAttribute(firstProductLink)}" target="_blank" rel="noopener">Shop product directly ↗</a>`
      : `<span class="product-link disabled" title="Add an exact verified product page URL in products.json">Product link not added yet</span>`;
    const stretch = product.price > budget
      ? `<div class="stretch-note"><b>Over budget by AED ${money(product.over_budget_by)}.</b> Consider stretching only if the extra features solve a real need. Compare the trade-off before deciding.</div>`
      : "";
    const bullets = [
      ...(product.pros || []).slice(0, 2).map(x => `✓ ${x}`),
      ...(product.cons || []).slice(0, 1).map(x => `Watch out: ${x}`)
    ].map(x => `<li>${escapeHtml(x)}</li>`).join("");

    return `
      <article class="product-card">
        <div class="product-art"><span class="product-category">${escapeHtml(product.category)}</span>${product.emoji || "🛍️"}</div>
        <div class="product-content">
          <div class="brand">${escapeHtml(product.brand)}</div>
          <h3>${escapeHtml(product.name)}</h3>
          <div class="description">${escapeHtml(product.description)}</div>
          <div class="price">AED ${money(product.price)}</div>
          <div class="product-meta"><span class="verdict ${verdictClass}">${product.verdict}</span><span class="score">${product.match_score}/100 match</span></div>
          <ul class="pros-cons">${bullets}</ul>
          <div class="store-prices">${retailerRows}</div>
          ${stretch}
          ${linkMarkup}
        </div>
      </article>`;
  }).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}
function escapeAttribute(value) { return escapeHtml(value); }

$("findButton").addEventListener("click", findProducts);
$("query").addEventListener("keydown", event => { if (event.key === "Enter") findProducts(); });

function toggleChat() { $("chatPanel").classList.toggle("open"); }
$("chatFab").addEventListener("click", toggleChat);
$("openChatTop").addEventListener("click", toggleChat);
$("openChatHero").addEventListener("click", toggleChat);
$("closeChat").addEventListener("click", toggleChat);

$("chatForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = $("chatInput").value.trim();
  if (!message) return;
  addMessage(message, "user");
  $("chatInput").value = "";
  addMessage("Thinking…", "bot", true);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });
    const data = await response.json();
    document.querySelector(".message.thinking")?.remove();
    addMessage(data.reply || "I couldn't prepare a response just now.", "bot");
  } catch {
    document.querySelector(".message.thinking")?.remove();
    addMessage("I couldn't reach the chat service. Please try again.", "bot");
  }
});

function addMessage(text, type, thinking = false) {
  const message = document.createElement("div");
  message.className = `message ${type}${thinking ? " thinking" : ""}`;
  message.textContent = text;
  $("chatMessages").appendChild(message);
  $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
}

findProducts();
